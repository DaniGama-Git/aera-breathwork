// --- Tabs ---
const tabBreathe = document.getElementById("tab-breathe");
const tabSettings = document.getElementById("tab-settings");
const breathePanel = document.getElementById("breathe-panel");
const settingsPanel = document.getElementById("settings-panel");

tabBreathe.addEventListener("click", () => {
  tabBreathe.classList.add("active");
  tabSettings.classList.remove("active");
  breathePanel.classList.remove("hidden");
  settingsPanel.classList.remove("visible");
});

tabSettings.addEventListener("click", () => {
  tabSettings.classList.add("active");
  tabBreathe.classList.remove("active");
  breathePanel.classList.add("hidden");
  settingsPanel.classList.add("visible");
  loadSettings();
});

// --- Settings ---
const icalInput = document.getElementById("ical-url");
const keywordsInput = document.getElementById("keywords");
const leadInput = document.getElementById("lead-minutes");
const saveBtn = document.getElementById("save-btn");
const statusEl = document.getElementById("status");
const connectionDot = document.getElementById("connection-dot");
const connectionText = document.getElementById("connection-text");

async function loadSettings() {
  const data = await chrome.storage.local.get(["icalUrl", "keywords", "leadMinutes"]);
  icalInput.value = data.icalUrl || "";
  keywordsInput.value = (data.keywords || []).join(", ");
  leadInput.value = data.leadMinutes ?? 2;
  updateConnectionStatus(!!data.icalUrl);
}

function updateConnectionStatus(connected) {
  connectionDot.classList.toggle("connected", connected);
  connectionText.textContent = connected ? "Calendar connected" : "Not configured";
}

saveBtn.addEventListener("click", async () => {
  const icalUrl = icalInput.value.trim();
  const keywords = keywordsInput.value.split(",").map((k) => k.trim()).filter(Boolean);
  const leadMinutes = parseInt(leadInput.value) || 2;

  if (!icalUrl) {
    showStatus("Please enter your iCal URL", true);
    return;
  }
  if (keywords.length === 0) {
    showStatus("Please enter at least one keyword", true);
    return;
  }

  try {
    const result = await chrome.runtime.sendMessage({
      type: "validate-calendar-url",
      icalUrl,
    });

    if (!result?.ok) {
      showStatus(result?.error || "Could not reach calendar. Check the URL.", true);
      return;
    }
  } catch (e) {
    showStatus("Could not validate calendar. Please reload the extension and try again.", true);
    return;
  }

  await chrome.storage.local.set({ icalUrl, keywords, leadMinutes });
  updateConnectionStatus(true);
  showStatus(`Saved! Watching for: ${keywords.join(", ")}`);
});

function showStatus(msg, isError = false) {
  statusEl.textContent = msg;
  statusEl.className = "status visible" + (isError ? " error" : "");
  setTimeout(() => (statusEl.className = "status"), 4000);
}

// Load connection status on open
chrome.storage.local.get(["icalUrl"], (data) => {
  updateConnectionStatus(!!data.icalUrl);
});

// --- Breathing Exercise ---
const circle = document.getElementById("circle");
const label = document.getElementById("label");
const btn = document.getElementById("btn");
const dotsEl = document.getElementById("dots");
const timerEl = document.getElementById("timer");

const PHASES = ["inhale", "hold", "exhale"];
const LABELS = { inhale: "Breathe in", hold: "Hold", exhale: "Breathe out" };
const DURATION = 4000;
const TOTAL_CYCLES = 4;

let running = false;
let phase = "idle";
let cycleIdx = 0;
let phaseIdx = 0;
let timeout = null;
let countdownInterval = null;

function renderDots() {
  if (!running) { dotsEl.innerHTML = ""; return; }
  dotsEl.innerHTML = Array.from({ length: TOTAL_CYCLES }, (_, i) =>
    `<div class="dot ${i <= cycleIdx ? "filled" : ""}"></div>`
  ).join("");
}

function startCountdown(seconds) {
  let remaining = seconds;
  timerEl.textContent = remaining;
  countdownInterval = setInterval(() => {
    remaining--;
    if (remaining > 0) timerEl.textContent = remaining;
    else { clearInterval(countdownInterval); timerEl.textContent = ""; }
  }, 1000);
}

function setPhase(p) {
  phase = p;
  clearInterval(countdownInterval);
  circle.className = "circle " + p;
  if (p !== "idle") circle.classList.add("active");
  label.textContent = LABELS[p] || "Ready?";
  if (p !== "idle") startCountdown(4);
  else timerEl.textContent = "";
  if (p === "idle") return;

  timeout = setTimeout(() => {
    phaseIdx++;
    if (phaseIdx < PHASES.length) {
      setPhase(PHASES[phaseIdx]);
    } else {
      cycleIdx++;
      renderDots();
      if (cycleIdx >= TOTAL_CYCLES) {
        stop();
        label.textContent = "Well done ✓";
      } else {
        phaseIdx = 0;
        setPhase(PHASES[0]);
      }
    }
  }, DURATION);
}

function start() {
  running = true;
  cycleIdx = 0;
  phaseIdx = 0;
  btn.textContent = "Stop";
  renderDots();
  setPhase("inhale");
}

function stop() {
  running = false;
  clearTimeout(timeout);
  clearInterval(countdownInterval);
  timerEl.textContent = "";
  circle.className = "circle idle";
  btn.textContent = "Start";
  renderDots();
}

btn.addEventListener("click", () => (running ? stop() : start()));

// Auto-start if opened from notification
chrome.storage.local.get(["autoStart"], (data) => {
  if (data.autoStart) {
    chrome.storage.local.remove("autoStart");
    start();
  }
});
