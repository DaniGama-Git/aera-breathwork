// background.js — polls Google Calendar iCal feed and triggers popup

const CHECK_INTERVAL_MINUTES = 1;
const ALARM_NAME = "check-calendar";

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: CHECK_INTERVAL_MINUTES });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  await checkCalendar();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "validate-calendar-url") return;

  validateCalendarUrl(message.icalUrl)
    .then(sendResponse)
    .catch((error) => {
      sendResponse({
        ok: false,
        error: error?.message || "Could not reach calendar. Check the URL.",
      });
    });

  return true;
});

async function validateCalendarUrl(icalUrl) {
  if (!icalUrl || !/^https:\/\/calendar\.google\.com\/calendar\/ical\//i.test(icalUrl)) {
    return { ok: false, error: "Please enter a valid Google Calendar iCal URL." };
  }

  const res = await fetch(icalUrl, { redirect: "follow" });
  if (!res.ok) {
    return { ok: false, error: `Calendar request failed (${res.status}).` };
  }

  const text = await res.text();
  if (!text.includes("BEGIN:VCALENDAR")) {
    return { ok: false, error: "This URL does not return a valid iCal feed." };
  }

  return { ok: true };
}

async function checkCalendar() {
  const data = await chrome.storage.local.get(["icalUrl", "keywords", "leadMinutes", "triggeredEvents"]);
  const { icalUrl, keywords, leadMinutes = 2, triggeredEvents = {} } = data;

  if (!icalUrl || !keywords || keywords.length === 0) return;

  try {
    const res = await fetch(icalUrl);
    if (!res.ok) return;
    const text = await res.text();

    const events = parseIcal(text);
    const now = Date.now();
    const windowMs = leadMinutes * 60 * 1000;

    for (const evt of events) {
      const timeDiff = evt.start - now;
      // Trigger if event starts within the lead window and hasn't been triggered yet
      if (timeDiff > -60000 && timeDiff <= windowMs) {
        const matchesKeyword = keywords.some((kw) =>
          evt.summary.toLowerCase().includes(kw.toLowerCase())
        );
        if (matchesKeyword && !triggeredEvents[evt.uid]) {
          // Mark as triggered
          triggeredEvents[evt.uid] = Date.now();
          await chrome.storage.local.set({ triggeredEvents });

          // Show notification that opens popup
          chrome.action.openPopup?.() ||
            chrome.notifications.create(evt.uid, {
              type: "basic",
              iconUrl: "icon.png",
              title: "Time to Breathe 🌿",
              message: `"${evt.summary}" is starting — take a breathing break!`,
            });
        }
      }
    }

    // Clean up old triggered events (older than 24h)
    const cutoff = now - 24 * 60 * 60 * 1000;
    for (const uid of Object.keys(triggeredEvents)) {
      if (triggeredEvents[uid] < cutoff) delete triggeredEvents[uid];
    }
    await chrome.storage.local.set({ triggeredEvents });
  } catch (e) {
    console.error("Breathe: calendar check failed", e);
  }
}

function parseIcal(text) {
  const events = [];
  const blocks = text.split("BEGIN:VEVENT");

  for (let i = 1; i < blocks.length; i++) {
    const block = blocks[i].split("END:VEVENT")[0];
    const summary = extractField(block, "SUMMARY") || "";
    const dtstart = extractField(block, "DTSTART");
    const uid = extractField(block, "UID") || `evt-${i}`;

    if (dtstart) {
      const start = parseIcalDate(dtstart);
      if (start) events.push({ summary, start, uid });
    }
  }
  return events;
}

function extractField(block, field) {
  // Handle both "FIELD:" and "FIELD;...:" formats
  const regex = new RegExp(`^${field}[;:](.*)$`, "m");
  const match = block.match(regex);
  if (!match) return null;
  let value = match[1];
  // If it has params like TZID, the actual value is after the last ':'
  if (match[0].includes(";")) {
    const colonIdx = value.indexOf(":");
    if (colonIdx !== -1) value = value.substring(colonIdx + 1);
  }
  return value.trim().replace(/\\n/g, " ").replace(/\r/g, "");
}

function parseIcalDate(str) {
  // Format: 20240327T140000Z or 20240327T140000
  const clean = str.replace(/[^0-9TZ]/g, "");
  const m = clean.match(/(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})/);
  if (!m) return null;
  const iso = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}${clean.endsWith("Z") ? "Z" : ""}`;
  return new Date(iso).getTime();
}

// Also check on notification click
chrome.notifications.onClicked.addListener((notificationId) => {
  chrome.notifications.clear(notificationId);
  // Open popup by focusing extension
  chrome.action.openPopup?.();
});
