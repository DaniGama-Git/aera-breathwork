// āera Pre-Pitch Breathwork Session
// Total: ~3 minutes

const $ = (id) => document.getElementById(id);
const phases = ["p-start","p-arrive","p-box","p-exhale","p-activate","p-land"];
let currentPhase = "p-start";
let aborted = false;

function showPhase(id) {
  currentPhase = id;
  phases.forEach(p => $(p).classList.toggle("active", p === id));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── Phase 2: Box Breathing ──
function runBoxBreathing() {
  return new Promise(async (resolve) => {
    const canvas = $("box-canvas");
    const ctx = canvas.getContext("2d");
    const w = canvas.width, h = canvas.height;
    const pad = 40;
    const labels = ["Inhale", "Hold", "Exhale", "Hold"];
    const textEl = $("box-text");
    const sideTime = 4000; // 4s per side
    const totalCycles = 3;

    const corners = [
      [pad, pad],           // top-left
      [w - pad, pad],       // top-right
      [w - pad, h - pad],   // bottom-right
      [pad, h - pad],       // bottom-left
    ];

    for (let cycle = 0; cycle < totalCycles && !aborted; cycle++) {
      for (let side = 0; side < 4 && !aborted; side++) {
        textEl.textContent = labels[side];
        const [x1, y1] = corners[side];
        const [x2, y2] = corners[(side + 1) % 4];
        const start = performance.now();

        await new Promise((res) => {
          function draw(now) {
            if (aborted) { res(); return; }
            const t = Math.min((now - start) / sideTime, 1);
            const cx = x1 + (x2 - x1) * t;
            const cy = y1 + (y2 - y1) * t;

            // Draw completed sides
            ctx.clearRect(0, 0, w, h);
            ctx.strokeStyle = "rgba(255,255,255,0.25)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(corners[0][0], corners[0][1]);
            for (let i = 1; i <= 4; i++) ctx.lineTo(corners[i % 4][0], corners[i % 4][1]);
            ctx.stroke();

            // Draw active path
            ctx.strokeStyle = "rgba(255,255,255,0.8)";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(corners[0][0], corners[0][1]);
            // completed sides this cycle
            for (let s = 0; s < side; s++) {
              ctx.lineTo(corners[(s + 1) % 4][0], corners[(s + 1) % 4][1]);
            }
            ctx.lineTo(cx, cy);
            ctx.stroke();

            // Dot
            ctx.fillStyle = "#fff";
            ctx.beginPath();
            ctx.arc(cx, cy, 3, 0, Math.PI * 2);
            ctx.fill();

            if (t < 1) requestAnimationFrame(draw);
            else res();
          }
          requestAnimationFrame(draw);
        });
      }
    }
    resolve();
  });
}

// ── Phase 3: Extended Exhale ──
function runExtendedExhale() {
  return new Promise(async (resolve) => {
    const bar = $("line-bar");
    const textEl = $("exhale-text");
    const inhaleTime = 4000;
    const exhaleTime = 8000;
    const cycles = 4;

    for (let i = 0; i < cycles && !aborted; i++) {
      // Inhale — rise
      textEl.textContent = "Inhale";
      bar.style.transition = `height ${inhaleTime}ms ease-in-out`;
      bar.style.height = "100%";
      await sleep(inhaleTime + 100);

      if (aborted) break;

      // Exhale — descend slowly
      textEl.textContent = "Exhale slowly";
      bar.style.transition = `height ${exhaleTime}ms ease-in-out`;
      bar.style.height = "4px";
      await sleep(exhaleTime + 100);
    }
    resolve();
  });
}

// ── Phase 4: Activation ──
function runActivation() {
  return new Promise(async (resolve) => {
    const canvas = $("pulse-canvas");
    const ctx = canvas.getContext("2d");
    const w = canvas.width, h = canvas.height;
    const cycles = 3;
    const inhaleTime = 800;
    const exhaleTime = 3200;
    const textEl = $("activate-text");

    for (let i = 0; i < cycles && !aborted; i++) {
      // Sharp inhale up
      const inStart = performance.now();
      await new Promise((res) => {
        function draw(now) {
          if (aborted) { res(); return; }
          const t = Math.min((now - inStart) / inhaleTime, 1);
          ctx.clearRect(0, 0, w, h);
          ctx.strokeStyle = "rgba(255,255,255,0.8)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(w * 0.2, h * 0.7);
          const peakX = w * 0.2 + (w * 0.3) * t;
          const peakY = h * 0.7 - (h * 0.5) * t;
          ctx.lineTo(peakX, peakY);
          ctx.stroke();
          if (t < 1) requestAnimationFrame(draw);
          else res();
        }
        requestAnimationFrame(draw);
      });

      if (aborted) break;

      // Slow exhale down
      const exStart = performance.now();
      await new Promise((res) => {
        function draw(now) {
          if (aborted) { res(); return; }
          const t = Math.min((now - exStart) / exhaleTime, 1);
          ctx.clearRect(0, 0, w, h);
          ctx.strokeStyle = "rgba(255,255,255,0.8)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          // Full inhale line
          ctx.moveTo(w * 0.2, h * 0.7);
          ctx.lineTo(w * 0.5, h * 0.2);
          // Exhale descending
          const endX = w * 0.5 + (w * 0.3) * t;
          const endY = h * 0.2 + (h * 0.5) * t;
          ctx.lineTo(endX, endY);
          ctx.stroke();
          if (t < 1) requestAnimationFrame(draw);
          else res();
        }
        requestAnimationFrame(draw);
      });

      await sleep(200);
    }
    resolve();
  });
}

// ── Main sequence ──
async function run() {
  aborted = false;

  // Phase 1: Arrive (20s)
  showPhase("p-arrive");
  await sleep(20000);
  if (aborted) return;

  // Phase 2: Box Breathing (~60s)
  showPhase("p-box");
  await runBoxBreathing();
  if (aborted) return;

  // Phase 3: Extended Exhale (~60s)
  showPhase("p-exhale");
  $("line-bar").style.height = "4px";
  $("line-bar").style.transition = "none";
  await sleep(50);
  await runExtendedExhale();
  if (aborted) return;

  // Phase 4: Activation (~30s)
  showPhase("p-activate");
  await runActivation();
  if (aborted) return;

  // Phase 5: Land (10s)
  showPhase("p-land");
  await sleep(10000);
}

$("start-btn").addEventListener("click", run);
